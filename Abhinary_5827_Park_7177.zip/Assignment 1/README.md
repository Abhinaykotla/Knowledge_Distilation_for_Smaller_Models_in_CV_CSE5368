# Assignment 1

Dataset from https://www.kaggle.com/datasets/sobhanmoosavi/us-road-construction-and-closures/data
